import os
import sys
import json
import time
import datetime
import threading
import socket
import logging
import webview
from core.database import LocalDatabase
from core.sync_service import SyncService
from core.attendance_engine import AttendanceEngine
from core.rfid_listener import RFIDListener
from core.updater import AutoUpdater

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] (%(name)s) %(message)s"
)
logger = logging.getLogger("App")

class KioskAPI:
    """
    Exposed API accessible from JavaScript in UI via window.pywebview.api.*
    Note: Attributes must start with '_' so pywebview reflection does not
    inspect them recursively into .NET / COM objects!
    """
    def __init__(self, on_tap_cb, sync_cb, status_cb, exit_cb=None, lockdown_cb=None, pair_cb=None, handshake_cb=None, sysinfo_cb=None, check_update_cb=None, apply_update_cb=None):
        self._on_tap_cb = on_tap_cb
        self._sync_cb = sync_cb
        self._status_cb = status_cb
        self._exit_cb = exit_cb
        self._lockdown_cb = lockdown_cb
        self._pair_cb = pair_cb
        self._handshake_cb = handshake_cb
        self._sysinfo_cb = sysinfo_cb
        self._check_update_cb = check_update_cb
        self._apply_update_cb = apply_update_cb

    def get_system_info(self):
        if self._sysinfo_cb:
            return self._sysinfo_cb()
        return {}

    def perform_handshake(self, server_url, setup_code):
        if self._handshake_cb:
            return self._handshake_cb(server_url, setup_code)
        return {"success": False, "message": "Handler handshake tidak siap"}

    def pair_device(self, setup_code, pairing_code):
        if self._pair_cb:
            return self._pair_cb(setup_code, pairing_code)
        return {"success": False, "message": "Handler aktivasi tidak siap"}

    def on_rfid_tap(self, card_uid, active_event_id=0, active_device_id=0):
        if self._on_tap_cb:
            return self._on_tap_cb(card_uid, active_event_id, active_device_id)
        return None

    def trigger_sync(self):
        if self._sync_cb:
            return self._sync_cb()
        return False

    def get_status(self):
        if self._status_cb:
            return self._status_cb()
        return {}

    def exit_app(self):
        if self._exit_cb:
            return self._exit_cb()
        return False

    def set_lockdown(self, enabled):
        if self._lockdown_cb:
            return self._lockdown_cb(enabled)
        return False

    def check_update(self):
        if self._check_update_cb:
            return self._check_update_cb()
        return {"success": False, "has_update": False, "message": "Handler update tidak tersedia"}

    def apply_update(self, download_url):
        if self._apply_update_cb:
            return self._apply_update_cb(download_url)
        return {"success": False, "message": "Handler update tidak tersedia"}

class SmartTapKioskApp:
    def __init__(self):
        # Resolve base directory & exe directory
        if getattr(sys, 'frozen', False):
            self.exe_dir = os.path.dirname(sys.executable)
            self.base_dir = getattr(sys, '_MEIPASS', self.exe_dir)
        else:
            self.exe_dir = os.path.dirname(os.path.abspath(__file__))
            self.base_dir = self.exe_dir

        # config.json: prioritized next to executable so user can edit it
        self.config_path = os.path.join(self.exe_dir, "config.json")
        if not os.path.exists(self.config_path):
            self.config_path = os.path.join(self.base_dir, "config.json")

        self.config = self.load_config()

        # Database is stored next to executable so data is always persistent
        db_path = os.path.join(self.exe_dir, "absensi.db")
        self.db = LocalDatabase(db_path)

        # Sync service
        self.sync_service = SyncService(
            db=self.db,
            server_url=str(self.config.get("server_url", "")),
            device_token=str(self.config.get("device_token", "")),
            interval=int(self.config.get("sync_interval_seconds", 15)),
            retention_days=int(self.config.get("log_retention_days", 1))
        )

        # Engine
        self.engine = AttendanceEngine(self.db)

        # Auto Updater
        self.updater = AutoUpdater(self.exe_dir, self.config_path)

        # Global RFID hook listener
        self.rfid_listener = RFIDListener(callback=self.handle_card_tap, enable_lockdown=False)

        # Hardware tap debounce
        self.last_tap_uid = None
        self.last_tap_time: float = 0.0

        self.window = None
        self.is_running = True

    def load_config(self):
        default_config = {
            "server_url": "",
            "device_token": "",
            "kiosk_fullscreen": True,
            "kiosk_lockdown": True,
            "sync_interval_seconds": 15,
            "sound_enabled": True,
            "log_retention_days": 1
        }
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    return {**default_config, **json.load(f)}
            except Exception as e:
                logger.error(f"Error loading config.json: {e}")
        return default_config

    def handle_card_tap(self, card_uid, active_event_id=0, active_device_id=0):
        """
        Triggered when RFID card is tapped (via global hook or UI input)
        """
        card_uid = str(card_uid).strip().upper()
        now = time.time()

        # Hardware input debounce: prevent burst double-reads within 2.5s
        if self.last_tap_uid == card_uid and (now - self.last_tap_time < 2.5):
            logger.info(f"Debounce: Card {card_uid} burst tap ignored (within 2.5s window)")
            return None

        self.last_tap_uid = card_uid
        self.last_tap_time = now

        logger.info(f"Processing Tap for UID: {card_uid} (Event: {active_event_id}, Device: {active_device_id})")
        result = self.engine.process_tap(card_uid, active_event_id, active_device_id)

        # Push result to UI window
        if self.window:
            js_code = f"showTapResult({json.dumps(result)});"
            try:
                self.window.evaluate_js(js_code)
            except Exception as e:
                logger.error(f"Failed to evaluate JS on tap: {e}")

        # Update stats
        self.push_status_to_ui()
        return result

    def get_current_status(self):
        stats = self.db.get_stats_summary()
        active_events = self.db.get_active_events()
        device_info = self.db.get_device_info()
        is_paired = bool(self.config.get("device_token")) and bool(self.sync_service.device_token)

        return {
            "is_online": self.sync_service.is_online,
            "is_paired": is_paired,
            "clock_drift": self.sync_service.clock_drift_warning,
            "current_version": self.updater.get_current_version(),
            "device": device_info,
            "events": active_events,
            "stats": stats
        }

    def get_system_info(self):
        """
        Mengumpulkan info lokal untuk Step 1 wizard inisiasi
        """
        hostname = socket.gethostname()
        local_ip = "127.0.0.1"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except Exception:
            pass

        now = datetime.datetime.now()
        return {
            "hostname": hostname,
            "ip": local_ip,
            "local_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "server_url": self.config.get("server_url", ""),
            "has_token": bool(self.config.get("device_token"))
        }

    def handle_handshake(self, server_url, setup_code):
        info = self.get_system_info()
        result = self.sync_service.perform_handshake(server_url, setup_code, hostname=info.get("hostname", ""))
        return result

    def handle_device_pairing(self, setup_code, pairing_code):
        result = self.sync_service.pair_with_code(setup_code, pairing_code)
        if result.get("success"):
            new_token = result.get("token")
            device_info = result.get("device", {})

            # Simpan url dan token baru ke config.json
            self.config["server_url"] = str(self.sync_service.server_url)
            self.config["device_token"] = str(new_token or "")
            try:
                with open(self.config_path, "w", encoding="utf-8") as f:
                    json.dump(self.config, f, indent=2)
                logger.info("Saved server_url & device_token into config.json")
            except Exception as e:
                logger.error(f"Failed to save config.json: {e}")

            # Also update device info in SQLite
            if device_info:
                self.db.update_master_data({"device": device_info})

            # Trigger immediate background sync
            threading.Thread(target=self.sync_now, daemon=True).start()

        return result

    def push_status_to_ui(self):
        if not self.window:
            return
        try:
            status = self.get_current_status()
            js_code = f"updateSystemStatus({json.dumps(status)});"
            self.window.evaluate_js(js_code)
        except Exception:
            pass

    def sync_now(self):
        """
        Manual or initial sync
        """
        self.sync_service.sync_master()
        self.sync_service.sync_logs()
        self.push_status_to_ui()

    def sync_loop(self):
        """
        Background loop for periodic synchronization
        """
        # Initial wait for UI to finish loading
        time.sleep(2)
        self.sync_now()

        interval = max(5.0, float(self.config.get("sync_interval_seconds", 15)))
        while self.is_running:
            time.sleep(interval)
            try:
                # 1. Sync any unsynced logs first
                self.sync_service.sync_logs()
                # 2. Ping / sync master periodically
                self.sync_service.ping()
                # 3. Update UI
                self.push_status_to_ui()
            except Exception as e:
                logger.error(f"Error in background sync worker: {e}")

    def set_lockdown_state(self, enabled: bool):
        lockdown_allowed = bool(self.config.get("kiosk_lockdown", True))
        actual = enabled and lockdown_allowed
        self.rfid_listener.set_lockdown(actual)
        return actual

    def handle_check_update(self):
        server_url = str(self.config.get("server_url", ""))
        return self.updater.check_for_update(server_url)

    def handle_apply_update(self, download_url):
        def progress_cb(pct, msg):
            if self.window:
                try:
                    js = f"onUpdateProgress({pct}, {json.dumps(msg)});"
                    self.window.evaluate_js(js)
                except Exception:
                    pass

        threading.Thread(
            target=lambda: self.updater.download_and_apply_update(download_url, progress_cb),
            daemon=True
        ).start()
        return {"success": True, "message": "Proses unduh update dimulai"}

    def exit_app(self):
        logger.info("Application exit requested via UI.")
        self.is_running = False
        self.rfid_listener.stop()
        if self.window:
            try:
                self.window.destroy()
            except Exception:
                pass
        os._exit(0)

    def run(self):
        # Start RFID Hook
        self.rfid_listener.start()

        # Start Background Sync Thread
        sync_thread = threading.Thread(target=self.sync_loop, daemon=True)
        sync_thread.start()

        # UI Path
        ui_path = os.path.join(self.base_dir, "ui", "index.html")
        if not os.path.exists(ui_path):
            ui_path = os.path.join(self.exe_dir, "ui", "index.html")

        # Create Native Webview Window with clean callbacks (prevents recursive COM reflection)
        api = KioskAPI(
            on_tap_cb=self.handle_card_tap,
            sync_cb=self.sync_now,
            status_cb=self.get_current_status,
            exit_cb=self.exit_app,
            lockdown_cb=self.set_lockdown_state,
            pair_cb=self.handle_device_pairing,
            handshake_cb=self.handle_handshake,
            sysinfo_cb=self.get_system_info,
            check_update_cb=self.handle_check_update,
            apply_update_cb=self.handle_apply_update
        )
        fullscreen = bool(self.config.get("kiosk_fullscreen", True))

        self.window = webview.create_window(
            title="Smart Tap Terminal Kiosk",
            url=ui_path,
            js_api=api,
            width=1024,
            height=768,
            fullscreen=fullscreen,
            frameless=fullscreen,
            on_top=fullscreen,
            easy_drag=not fullscreen
        )

        logger.info("Starting Webview Kiosk UI...")
        webview.start(debug=False)

        # Cleanup on exit
        self.is_running = False
        self.rfid_listener.stop()

if __name__ == "__main__":
    app = SmartTapKioskApp()
    app.run()
