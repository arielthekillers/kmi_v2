import os
import sys
import json
import time
import datetime
import threading
import socket
import logging
import queue
import webview

from core.database import LocalDatabase
from core.sync_service import SyncService
from core.attendance_engine import AttendanceEngine
from core.rfid_listener import RFIDListener
from core.raw_input import RawInputScannerListener
from core.updater import AutoUpdater

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] (%(name)s) %(message)s"
)
logger = logging.getLogger("App")

class KioskAPI:
    """
    Exposed API accessible from JavaScript in UI via window.pywebview.api.*
    Note: Attributes must start with '_' so pywebview reflection does not
    inspect them recursively into .NET / COM objects!
    """
    def __init__(self, on_tap_cb, sync_cb, status_cb, exit_cb=None, lockdown_cb=None, pair_cb=None, handshake_cb=None, sysinfo_cb=None, check_update_cb=None, apply_update_cb=None):
        self._on_tap_cb = on_tap_cb
        self._sync_cb = sync_cb
        self._status_cb = status_cb
        self._exit_cb = exit_cb
        self._lockdown_cb = lockdown_cb
        self._pair_cb = pair_cb
        self._handshake_cb = handshake_cb
        self._sysinfo_cb = sysinfo_cb
        self._check_update_cb = check_update_cb
        self._apply_update_cb = apply_update_cb

    def get_system_info(self):
        if self._sysinfo_cb:
            return self._sysinfo_cb()
        return {}

    def perform_handshake(self, server_url, setup_code):
        if self._handshake_cb:
            return self._handshake_cb(server_url, setup_code)
        return {"success": False, "message": "Handler handshake tidak siap"}

    def pair_device(self, setup_code, pairing_code):
        if self._pair_cb:
            return self._pair_cb(setup_code, pairing_code)
        return {"success": False, "message": "Handler aktivasi tidak siap"}

    def on_rfid_tap(self, card_uid, active_event_id=0, active_device_id=0):
        if self._on_tap_cb:
            return self._on_tap_cb(card_uid, active_event_id, active_device_id)
        return None

    def trigger_sync(self):
        if self._sync_cb:
            return self._sync_cb()
        return False

    def get_status(self):
        if self._status_cb:
            return self._status_cb()
        return {}

    def exit_app(self):
        if self._exit_cb:
            return self._exit_cb()
        return False

    def set_lockdown(self, enabled):
        if self._lockdown_cb:
            return self._lockdown_cb(enabled)
        return False

    def check_update(self):
        if self._check_update_cb:
            return self._check_update_cb()
        return {"success": False, "has_update": False, "message": "Handler update tidak tersedia"}

    def apply_update(self, download_url):
        if self._apply_update_cb:
            return self._apply_update_cb(download_url)
        return {"success": False, "message": "Handler update tidak tersedia"}

class SmartTapKioskApp:
    def __init__(self):
        # Resolve base directory & exe directory
        if getattr(sys, 'frozen', False):
            self.exe_dir = os.path.dirname(sys.executable)
            self.base_dir = getattr(sys, '_MEIPASS', self.exe_dir)
        else:
            self.exe_dir = os.path.dirname(os.path.abspath(__file__))
            self.base_dir = self.exe_dir

        # config.json: prioritized next to executable so user can edit it
        self.config_path = os.path.join(self.exe_dir, "config.json")
        if not os.path.exists(self.config_path):
            self.config_path = os.path.join(self.base_dir, "config.json")

        self.config = self.load_config()

        # Database is stored next to executable so data is always persistent
        db_path = os.path.join(self.exe_dir, "absensi.db")
        self.db = LocalDatabase(db_path)

        # Sync service
        self.sync_service = SyncService(
            db=self.db,
            server_url=str(self.config.get("server_url", "")),
            device_token=str(self.config.get("device_token", "")),
            interval=int(self.config.get("sync_interval_seconds", 15)),
            retention_days=int(self.config.get("log_retention_days", 1))
        )

        # Attendance Engine
        self.engine = AttendanceEngine(self.db)

        # Auto Updater
        self.updater = AutoUpdater(self.exe_dir, self.config_path)

        # Multi-Reader Concurrency: Thread-safe FIFO Queue & Worker
        self.tap_queue = queue.Queue()
        self.recent_taps_history = {} # { card_uid: last_tap_time }

        # Windows RawInput listener (Hardware USB isolation)
        self.raw_input_listener = RawInputScannerListener(on_scan_callback=self._on_raw_card_scanned)

        # Global RFID hook listener (Fallback)
        self.rfid_listener = RFIDListener(callback=self.handle_card_tap, enable_lockdown=False)

        self.window = None
        self.is_running = True

    def load_config(self):
        default_config = {
            "server_url": "",
            "device_token": "",
            "kiosk_fullscreen": True,
            "kiosk_lockdown": True,
            "sync_interval_seconds": 15,
            "sound_enabled": True,
            "log_retention_days": 1
        }
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    return {**default_config, **json.load(f)}
            except Exception as e:
                logger.error(f"Error loading config.json: {e}")
        return default_config

    def _on_raw_card_scanned(self, card_uid: str, device_handle: int):
        """
        Called directly by Windows RawInput when any physical USB RFID scanner finishes scanning.
        """
        logger.info(f"[RawInput] Scanned UID: {card_uid} from USB handle: {device_handle}")
        self.enqueue_card_tap(card_uid)

    def enqueue_card_tap(self, card_uid, active_event_id=0, active_device_id=0):
        """
        Thread-safe enqueue for taps from multiple scanners.
        Debounce is per-card UID, so different cards from different scanners process concurrently!
        """
        card_uid = str(card_uid).strip().upper()
        if not card_uid:
            return None

        now = time.time()
        last_time = self.recent_taps_history.get(card_uid, 0.0)

        # Debounce: abaikan jika kartu yang SAMA di-tap ulang dalam waktu < 2.5 detik
        if (now - last_time) < 2.5:
            logger.info(f"Debounce: Card {card_uid} burst tap ignored (within 2.5s window)")
            return None

        self.recent_taps_history[card_uid] = now

        # Bersihkan riwayat debounce yang sudah lebih dari 10 detik agar hemat memori
        if len(self.recent_taps_history) > 200:
            self.recent_taps_history = {k: v for k, v in self.recent_taps_history.items() if (now - v) < 10.0}

        # Masukkan ke FIFO queue
        self.tap_queue.put((card_uid, active_event_id, active_device_id))
        return {"queued": True, "uid": card_uid}

    def _tap_queue_worker(self):
        """
        Background worker that processes taps sequentially from the queue
        without blocking physical RFID scanner inputs.
        """
        logger.info("Tap Queue Worker started.")
        while self.is_running:
            try:
                item = self.tap_queue.get(timeout=0.3)
            except queue.Empty:
                continue

            card_uid, active_event_id, active_device_id = item
            try:
                logger.info(f"[Queue Worker] Processing tap for UID: {card_uid}")
                result = self.engine.process_tap(card_uid, active_event_id, active_device_id)

                # Push result immediately to UI
                if self.window:
                    js_code = f"showTapResult({json.dumps(result)});"
                    try:
                        self.window.evaluate_js(js_code)
                    except Exception as e:
                        logger.error(f"Failed to evaluate JS on tap: {e}")

                # Update stats summary
                self.push_status_to_ui()
            except Exception as e:
                logger.error(f"Error processing queued tap for {card_uid}: {e}", exc_info=True)
            finally:
                self.tap_queue.task_done()

    def handle_card_tap(self, card_uid, active_event_id=0, active_device_id=0):
        """
        Bridge for fallback hook or manual UI test tap
        """
        return self.enqueue_card_tap(card_uid, active_event_id, active_device_id)

    def get_current_status(self):
        stats = self.db.get_stats_summary()
        active_events = self.db.get_active_events()
        device_info = self.db.get_device_info()
        is_paired = bool(self.config.get("device_token")) and bool(self.sync_service.device_token)

        return {
            "is_online": self.sync_service.is_online,
            "is_paired": is_paired,
            "clock_drift": self.sync_service.clock_drift_warning,
            "current_version": self.updater.get_current_version(),
            "device": device_info,
            "events": active_events,
            "stats": stats
        }

    def get_system_info(self):
        try:
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
        except Exception:
            hostname = "KMI-KIOSK"
            ip_address = "127.0.0.1"

        return {
            "hostname": hostname,
            "ip_address": ip_address,
            "system_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    def handle_handshake(self, server_url, setup_code):
        server_url = str(server_url).strip().rstrip('/')
        setup_code = str(setup_code).strip()
        hostname = self.get_system_info().get("hostname", "")
        logger.info(f"Initiating Handshake with server {server_url} using setup code {setup_code}")

        res = self.sync_service.perform_handshake(server_url, setup_code, hostname)
        if res.get("success"):
            self.config["server_url"] = server_url
            self.save_config()
        return res

    def handle_device_pairing(self, setup_code, pairing_code):
        logger.info(f"Attempting device pairing with code: {pairing_code}")
        server_url = str(self.config.get("server_url", "") or "")
        if not server_url:
            return {"success": False, "message": "URL Server belum dikonfigurasi"}

        self.sync_service.server_url = server_url
        res = self.sync_service.pair_with_code(setup_code, pairing_code)
        if res.get("success"):
            token = res.get("token")
            device = res.get("device")
            device_id = device.get("id") if isinstance(device, dict) else None
            self.config["device_token"] = token
            self.config["device_id"] = device_id
            self.save_config()

            self.sync_service.device_token = token
            self.sync_service.sync_master()
            self.push_status_to_ui()
            return {"success": True, "message": "Perangkat berhasil diaktifkan!"}
        return res

    def save_config(self):
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4)
            logger.info("Config saved successfully.")
        except Exception as e:
            logger.error(f"Error saving config.json: {e}")

    def sync_now(self):
        return self.sync_service.sync_master()

    def push_status_to_ui(self):
        if not self.window:
            return
        status = self.get_current_status()
        js_code = f"updateSystemStatus({json.dumps(status)});"
        try:
            self.window.evaluate_js(js_code)
        except Exception:
            pass

    def sync_loop(self):
        while self.is_running:
            try:
                self.sync_service.sync_logs()
                self.sync_service.sync_master()
                self.push_status_to_ui()
            except Exception as e:
                logger.error(f"Error in sync loop: {e}")
            time.sleep(self.sync_service.interval)

    def set_lockdown_state(self, enabled):
        self.config["kiosk_lockdown"] = bool(enabled)
        self.save_config()
        self.rfid_listener.set_lockdown(bool(enabled))
        return True

    def exit_app(self):
        logger.info("Exit requested from UI.")
        self.is_running = False
        if self.window:
            self.window.destroy()

    def handle_check_update(self):
        server_url = str(self.config.get("server_url", "") or "")
        return self.updater.check_for_update(server_url)

    def handle_apply_update(self, download_url=None):
        def progress_cb(percent, message):
            if self.window:
                try:
                    js_code = f"window.onUpdateProgress && window.onUpdateProgress({percent}, {json.dumps(message)});"
                    self.window.evaluate_js(js_code)
                except Exception:
                    pass

        target_url = str(download_url or "") if download_url else None
        threading.Thread(
            target=lambda: self.updater.download_and_apply_update(target_url, progress_cb),
            daemon=True
        ).start()
        return {"success": True, "message": "Proses pembaruan dimulai di background..."}

    def run(self):
        # 1. Start Windows RawInput Multi-Reader Scanner Listener
        self.raw_input_listener.start()

        # 2. Start Tap Queue Worker
        queue_worker_thread = threading.Thread(target=self._tap_queue_worker, name="TapQueueWorkerThread", daemon=True)
        queue_worker_thread.start()

        # 3. Start Global RFID Hook Listener (Fallback)
        self.rfid_listener.start()

        # 4. Start Background Sync Thread
        sync_thread = threading.Thread(target=self.sync_loop, name="BackgroundSyncThread", daemon=True)
        sync_thread.start()

        # UI Path
        ui_path = os.path.join(self.base_dir, "ui", "index.html")
        if not os.path.exists(ui_path):
            ui_path = os.path.join(self.exe_dir, "ui", "index.html")

        # Create Native Webview Window with clean callbacks
        api = KioskAPI(
            on_tap_cb=self.handle_card_tap,
            sync_cb=self.sync_now,
            status_cb=self.get_current_status,
            exit_cb=self.exit_app,
            lockdown_cb=self.set_lockdown_state,
            pair_cb=self.handle_device_pairing,
            handshake_cb=self.handle_handshake,
            sysinfo_cb=self.get_system_info,
            check_update_cb=self.handle_check_update,
            apply_update_cb=self.handle_apply_update
        )
        fullscreen = bool(self.config.get("kiosk_fullscreen", True))

        self.window = webview.create_window(
            title="Smart Tap Terminal Kiosk",
            url=ui_path,
            js_api=api,
            width=1024,
            height=768,
            fullscreen=fullscreen,
            frameless=fullscreen,
            on_top=fullscreen,
            easy_drag=not fullscreen
        )

        logger.info("Starting Webview Kiosk UI...")
        webview.start(debug=False)

        # Cleanup on exit
        self.is_running = False
        self.raw_input_listener.stop()
        self.rfid_listener.stop()

if __name__ == "__main__":
    app = SmartTapKioskApp()
    app.run()
