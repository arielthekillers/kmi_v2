# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import zipfile
import logging
import requests
import subprocess
from typing import Dict, Any, Optional, Callable

logger = logging.getLogger("AutoUpdater")

def parse_version(ver_str: str):
    """Parses '1.2.3' into tuple (1, 2, 3) for accurate comparison"""
    try:
        clean = str(ver_str).strip().lstrip("vV")
        return tuple(int(x) for x in clean.split(".") if x.isdigit())
    except Exception:
        return (0, 0, 0)

class AutoUpdater:
    def __init__(self, base_dir: str, config_path: str):
        self.base_dir = base_dir
        self.config_path = config_path
        self.version_path = os.path.join(self.base_dir, "version.json")

    def get_current_version(self) -> str:
        if os.path.exists(self.version_path):
            try:
                with open(self.version_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return str(data.get("version", "1.0.0"))
            except Exception:
                pass
        return "1.0.0"

    def check_for_update(self, server_url: str) -> Dict[str, Any]:
        """
        Queries /api/smart-tap/version from server
        """
        current_ver = self.get_current_version()
        clean_url = str(server_url).strip().rstrip("/")
        if not clean_url:
            return {"success": False, "has_update": False, "message": "URL Server belum diatur"}

        url = f"{clean_url}/api/smart-tap/version"
        try:
            headers = {
                "Accept": "application/json, text/plain, */*",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 SmartTapKiosk/1.2"
            }
            resp = requests.get(url, headers=headers, timeout=8)
            if resp.status_code == 200:
                try:
                    data = resp.json()
                except Exception:
                    return {"success": False, "has_update": False, "message": "Respon server bukan format JSON yang valid"}

                if data.get("success"):
                    latest_ver = str(data.get("latest_version", "1.0.0"))
                    download_url = data.get("download_url") or ""
                    release_notes = data.get("release_notes") or "Pembaruan sistem Smart Tap"
                    exe_url = data.get("exe_download_url") or ""

                    has_update = parse_version(latest_ver) > parse_version(current_ver)

                    return {
                        "success": True,
                        "has_update": has_update,
                        "current_version": current_ver,
                        "latest_version": latest_ver,
                        "release_notes": release_notes,
                        "download_url": download_url,
                        "exe_download_url": exe_url
                    }
                return {"success": False, "has_update": False, "message": data.get("message", "Gagal memeriksa versi")}
            return {"success": False, "has_update": False, "message": f"Server merespon HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "has_update": False, "message": f"Koneksi gagal: {e}"}

    def download_and_apply_update(self, download_url: Optional[str] = None, progress_cb: Optional[Callable[[int, str], None]] = None) -> Dict[str, Any]:
        """
        Downloads update zip package, extracts files, and restarts application
        """
        if not download_url:
            # Fallback to server update URL check
            return {"success": False, "message": "URL unduhan pembaruan kosong"}

        temp_dir = os.environ.get("TEMP", os.path.dirname(self.base_dir))
        zip_path = os.path.join(temp_dir, "smart_tap_update_pkg.zip")

        try:
            if progress_cb:
                progress_cb(10, "Menghubungi server unduhan...")

            resp = requests.get(download_url, stream=True, timeout=60)
            if resp.status_code != 200:
                return {"success": False, "message": f"Gagal mengunduh file update (HTTP {resp.status_code})"}

            total_len = resp.headers.get("content-length")
            total_bytes = int(total_len) if total_len and total_len.isdigit() else 0
            downloaded = 0

            with open(zip_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_bytes > 0 and progress_cb:
                            pct = min(85, int(10 + (downloaded / total_bytes) * 75))
                            progress_cb(pct, f"Mengunduh pembaruan ({int(downloaded/1024)} KB)...")

            if progress_cb:
                progress_cb(90, "Memverifikasi integritas file...")

            # Test ZIP integrity
            with zipfile.ZipFile(zip_path, 'r') as zf:
                bad_file = zf.testzip()
                if bad_file:
                    return {"success": False, "message": f"File pembaruan rusak di arsip: {bad_file}"}

            if progress_cb:
                progress_cb(95, "Menyiapkan restart otomatis...")

            # Determine executable or script to restart
            if getattr(sys, 'frozen', False):
                restart_cmd = f'start "" "{sys.executable}"'
            else:
                run_bat = os.path.join(self.base_dir, "run.bat")
                if os.path.exists(run_bat):
                    restart_cmd = f'start "" "{run_bat}"'
                else:
                    restart_cmd = f'start "" "{sys.executable}" "{os.path.join(self.base_dir, "app.py")}"'

            # Build batch updater helper script
            bat_path = os.path.join(temp_dir, "smart_tap_apply.bat")
            ps_extract_cmd = f'powershell -Command "Expand-Archive -LiteralPath \'{zip_path}\' -DestinationPath \'{self.base_dir}\' -Force"'

            bat_content = f"""@echo off
title Smart Tap Auto-Updater
echo Menunggu aplikasi Kiosk menutup...
timeout /t 2 /nobreak >nul

echo Menerapkan file pembaruan...
{ps_extract_cmd}

echo Memulai kembali aplikasi Smart Tap...
timeout /t 1 /nobreak >nul
cd /d "{self.base_dir}"
{restart_cmd}

echo Membersihkan temporary installer...
del /f /q "{zip_path}" >nul 2>&1
(goto) 2>nul & del "%~f0"
exit
"""
            with open(bat_path, "w", encoding="utf-8") as f:
                f.write(bat_content)

            if progress_cb:
                progress_cb(100, "Memulai ulang aplikasi dengan versi baru...")

            time.sleep(0.8)

            # Launch batch updater detached in background
            creation_flag = subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
            subprocess.Popen(
                ["cmd.exe", "/c", bat_path],
                creationflags=creation_flag,
                close_fds=True
            )

            # Trigger application exit
            threading_timer = threading.Timer(1.0, lambda: os._exit(0))
            threading_timer.start()

            return {"success": True, "message": "Pembaruan berhasil diunduh. Aplikasi sedang dimulai ulang..."}

        except Exception as e:
            logger.error(f"Error applying update: {e}")
            return {"success": False, "message": f"Gagal menerapkan update: {e}"}

import threading
