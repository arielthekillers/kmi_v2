import hashlib
import datetime
import logging

logger = logging.getLogger("AttendanceEngine")

class AttendanceEngine:
    def __init__(self, db):
        self.db = db

    def process_tap(self, card_uid, active_event_id=0, active_device_id=0):
        """
        Processes an RFID tap matching the server's kioskTap rules
        """
        card_uid = str(card_uid).strip().upper()
        now = datetime.datetime.now()
        current_time_str = now.strftime("%H:%M:%S")
        current_date_str = now.strftime("%Y-%m-%d")
        current_datetime_str = now.strftime("%Y-%m-%d %H:%M:%S")

        # 1. Check card registration
        person = self.db.find_person_by_rfid(card_uid)
        if not person:
            return {
                "success": False,
                "status": "unregistered",
                "sound": "error",
                "message": "Kartu tidak dikenali!",
                "submessage": f"UID: {card_uid}",
                "person": None
            }

        person_type = person.get("person_type", "student")
        person_id = person["id"]
        person_name = person.get("nama", "Santri/Pegawai")
        person_info = person.get("kelas") if person_type == "student" else person.get("jabatan")
        person_nis = person.get("nis") if person_type == "student" else person.get("nip")
        photo = person.get("photo")

        person_payload = {
            "id": person_id,
            "nama": person_name,
            "info": person_info,
            "nis": person_nis,
            "photo": photo,
            "person_type": person_type,
            "card_uid": card_uid
        }

        # 2. Resolve active event (manual lock or auto schedule)
        events = self.db.get_active_events()
        event = None

        if active_event_id > 0:
            for ev in events:
                if ev["id"] == active_event_id:
                    event = ev
                    break

        # Fallback to auto time window matching
        if not event:
            sorted_events = sorted(events, key=lambda x: str(x.get("open_time", "00:00:00")))

            # Pass 1: Prioritas Utama - Sesi yang sedang buka resmi saat ini
            for ev in sorted_events:
                is_device_allowed = (ev.get("allow_any_device", 1) == 1) or \
                    (active_device_id > 0 and str(active_device_id) in str(ev.get("allowed_devices", "")).split(","))
                if not is_device_allowed:
                    continue

                open_t = ev.get("open_time", "00:00:00")
                close_t = ev.get("close_time", "23:59:59")
                if open_t <= current_time_str <= close_t:
                    event = ev
                    break

            # Pass 2: Jika tidak ada sesi resmi yang buka, cari sesi yang baru saja selesai & mengizinkan very_late
            if not event:
                for ev in sorted_events:
                    is_device_allowed = (ev.get("allow_any_device", 1) == 1) or \
                        (active_device_id > 0 and str(active_device_id) in str(ev.get("allowed_devices", "")).split(","))
                    if not is_device_allowed:
                        continue

                    open_t = ev.get("open_time", "00:00:00")
                    close_t = ev.get("close_time", "23:59:59")
                    allows_very_late = ev.get("after_close_action") == "very_late"

                    if current_time_str > close_t and allows_very_late:
                        event = ev  # Mengambil sesi terakhir yang selesai sebelum waktu saat ini

        if not event:
            return {
                "success": False,
                "status": "no_event",
                "sound": "error",
                "message": "Tidak ada sesi absensi aktif!",
                "person": person_payload
            }

        # Target audience check
        target = str(event.get("target_type", "all")).lower()
        if target in ["students", "santri"] and person_type != "student":
            return {
                "success": False,
                "status": "not_target",
                "sound": "error",
                "message": "Sesi ini khusus untuk Santri!",
                "person": person_payload
            }
        elif target in ["teachers", "teacher", "guru", "pegawai"] and person_type != "teacher":
            return {
                "success": False,
                "status": "not_target",
                "sound": "error",
                "message": "Sesi ini khusus untuk Pengajar / Pegawai!",
                "person": person_payload
            }

        open_time = event.get("open_time", "00:00:00")
        start_time = event.get("start_time", "00:00:00")
        close_time = event.get("close_time", "23:59:59")
        after_close = event.get("after_close_action", "reject")

        # Time evaluation
        if current_time_str < open_time:
            return {
                "success": False,
                "status": "not_started",
                "sound": "error",
                "message": f"Absensi belum dibuka (Buka jam {open_time[:5]})",
                "person": person_payload
            }

        status = "on_time"
        sound = "success"
        status_label = "HADIR TEPAT WAKTU"

        if current_time_str > start_time and current_time_str <= close_time:
            status = "late"
            sound = "late"
            status_label = "TERLAMBAT"
        elif current_time_str > close_time:
            if after_close == "very_late":
                status = "very_late"
                sound = "error"
                status_label = "SANGAT TERLAMBAT"
            else:
                return {
                    "success": False,
                    "status": "closed",
                    "sound": "error",
                    "message": f"Absensi telah ditutup jam {close_time[:5]}!",
                    "person": person_payload
                }

        # 4. Anti Double-Tap check (Deterministic log_uuid)
        log_seed = f"{event['id']}_{person_type}_{person_id}_{current_date_str}"
        log_uuid = hashlib.md5(log_seed.encode()).hexdigest()

        if self.db.check_already_tapped(log_uuid):
            return {
                "success": True,
                "status": "already_tapped",
                "sound": "success",
                "status_label": "SUDAH ABSEN SEBELUMNYA",
                "message": "Sudah melakukan absensi sebelumnya!",
                "event_name": event.get("name", "Event"),
                "time": now.strftime("%H:%M:%S"),
                "person": person_payload
            }

        # Save to local SQLite
        self.db.insert_log({
            "log_uuid": log_uuid,
            "event_id": event["id"],
            "device_id": active_device_id,
            "person_type": person_type,
            "person_id": person_id,
            "card_uid": card_uid,
            "tapped_at": current_datetime_str,
            "status": status,
            "note": f"Tap di {event.get('name')}"
        })

        return {
            "success": True,
            "status": status,
            "sound": sound,
            "status_label": status_label,
            "message": f"Absensi berhasil ({status_label})",
            "event_name": event.get("name", "Event"),
            "time": now.strftime("%H:%M:%S"),
            "person": person_payload
        }
