import sqlite3
import os
import logging

logger = logging.getLogger("Database")

class LocalDatabase:
    def __init__(self, db_path="absensi.db"):
        self.db_path = db_path
        self.init_tables()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_tables(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # SQLite Performance & Sudden Power-Cut Resilience (WAL Mode)
            cursor.execute("PRAGMA journal_mode = WAL")
            cursor.execute("PRAGMA synchronous = NORMAL")

            # Table for caching device info
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS device_info (
                    id INTEGER PRIMARY KEY,
                    code TEXT,
                    name TEXT,
                    pin_code TEXT,
                    location TEXT,
                    last_sync TEXT
                )
            """)

            # Master santri
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS master_students (
                    id INTEGER PRIMARY KEY,
                    nis TEXT,
                    nama TEXT,
                    kelas TEXT,
                    rfid_uid TEXT,
                    photo TEXT,
                    is_active INTEGER DEFAULT 1
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_students_rfid ON master_students(rfid_uid)")

            # Master guru/pegawai
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS master_teachers (
                    id INTEGER PRIMARY KEY,
                    nip TEXT,
                    nama TEXT,
                    jabatan TEXT,
                    rfid_uid TEXT,
                    photo TEXT,
                    is_active INTEGER DEFAULT 1
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_teachers_rfid ON master_teachers(rfid_uid)")

            # Today's active events matching kmi_v2 structure
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS today_events (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    category TEXT DEFAULT 'sholat',
                    event_type TEXT,
                    open_time TEXT,
                    start_time TEXT,
                    close_time TEXT,
                    after_close_action TEXT,
                    allowed_devices TEXT,
                    allow_any_device INTEGER DEFAULT 1,
                    target_type TEXT DEFAULT 'all',
                    is_active INTEGER DEFAULT 1
                )
            """)

            # Migration: ensure category column exists in today_events
            cursor.execute("PRAGMA table_info(today_events)")
            event_cols = [row[1] for row in cursor.fetchall()]
            if "category" not in event_cols:
                try:
                    cursor.execute("ALTER TABLE today_events ADD COLUMN category TEXT DEFAULT 'sholat'")
                except Exception:
                    pass

            # Attendance tap logs
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS attendance_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    log_uuid TEXT UNIQUE,
                    event_id INTEGER,
                    device_id INTEGER,
                    person_type TEXT,
                    person_id INTEGER,
                    card_uid TEXT,
                    tapped_at TEXT,
                    status TEXT,
                    note TEXT,
                    synced INTEGER DEFAULT 0
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_logs_synced ON attendance_logs(synced)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_logs_uuid ON attendance_logs(log_uuid)")
            conn.commit()
            logger.info("Local SQLite database initialized.")

    def update_master_data(self, data):
        """
        Updates master data from /api/smart-tap/sync-master payload
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # 1. Update Device Info
            device = data.get("device", {})
            if device:
                cursor.execute("DELETE FROM device_info")
                cursor.execute("""
                    INSERT INTO device_info (id, code, name, pin_code, location, last_sync)
                    VALUES (?, ?, ?, ?, ?, datetime('now', 'localtime'))
                """, (
                    device.get("id"),
                    device.get("code"),
                    device.get("name"),
                    device.get("pin_code", "1234"),
                    device.get("location")
                ))

            # 2. Update Students
            students = data.get("students", [])
            cursor.execute("DELETE FROM master_students")
            for s in students:
                cursor.execute("""
                    INSERT INTO master_students (id, nis, nama, kelas, rfid_uid, photo, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    s.get("id"),
                    s.get("nis", ""),
                    s.get("nama", ""),
                    s.get("kelas", "") or s.get("subinfo", ""),
                    s.get("rfid_uid") or s.get("card_uid") or "",
                    s.get("photo", ""),
                    s.get("is_active", 1)
                ))

            # 3. Update Teachers
            teachers = data.get("teachers", [])
            cursor.execute("DELETE FROM master_teachers")
            for t in teachers:
                cursor.execute("""
                    INSERT INTO master_teachers (id, nip, nama, jabatan, rfid_uid, photo, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    t.get("id"),
                    t.get("nip", "") or t.get("username", ""),
                    t.get("nama", ""),
                    t.get("jabatan", "") or "Pengajar",
                    t.get("rfid_uid") or t.get("card_uid") or "",
                    t.get("photo", ""),
                    t.get("is_active", 1)
                ))

            # 4. Update Today Events
            events = data.get("today_events", [])
            cursor.execute("DELETE FROM today_events")
            for e in events:
                category = e.get("category", "")
                name_lower = str(e.get("name") or e.get("event_name") or "").lower()
                if not category:
                    if "kantor" in name_lower or "office" in name_lower or "piket" in name_lower:
                        category = "office"
                    elif e.get("event_type") == "one_off":
                        category = "incidental"
                    else:
                        category = "sholat"

                cursor.execute("""
                    INSERT INTO today_events (
                        id, name, category, event_type, open_time, start_time, close_time,
                        after_close_action, allowed_devices, allow_any_device, target_type, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    e.get("id"),
                    e.get("name") or e.get("event_name"),
                    category,
                    e.get("event_type", "attendance"),
                    e.get("open_time", "00:00:00"),
                    e.get("start_time", "00:00:00"),
                    e.get("close_time", "23:59:59"),
                    e.get("after_close_action", "reject"),
                    e.get("allowed_devices", ""),
                    e.get("allow_any_device", 1),
                    e.get("target_type", "all"),
                    e.get("is_active", 1)
                ))

            conn.commit()

    def get_device_info(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM device_info LIMIT 1")
            row = cursor.fetchone()
            return dict(row) if row else {
                "id": 1,
                "code": "DEV-01",
                "name": "Terminal Scanner",
                "pin_code": "1234",
                "location": "Pintu Utama"
            }

    def find_person_by_rfid(self, rfid_uid):
        rfid = rfid_uid.strip()
        with self.get_connection() as conn:
            cursor = conn.cursor()
            # Search students
            cursor.execute("SELECT *, 'student' as person_type FROM master_students WHERE LOWER(rfid_uid) = LOWER(?)", (rfid,))
            student = cursor.fetchone()
            if student:
                return dict(student)

            # Search teachers
            cursor.execute("SELECT *, 'teacher' as person_type FROM master_teachers WHERE LOWER(rfid_uid) = LOWER(?)", (rfid,))
            teacher = cursor.fetchone()
            if teacher:
                return dict(teacher)
        return None

    def get_active_events(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM today_events WHERE is_active = 1 ORDER BY open_time ASC")
            return [dict(row) for row in cursor.fetchall()]

    def check_already_tapped(self, log_uuid):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM attendance_logs WHERE log_uuid = ? LIMIT 1", (log_uuid,))
            return cursor.fetchone() is not None

    def insert_log(self, log_dict):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO attendance_logs (
                    log_uuid, event_id, device_id, person_type, person_id, card_uid,
                    tapped_at, status, note, synced
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
            """, (
                log_dict["log_uuid"],
                log_dict.get("event_id", 0),
                log_dict.get("device_id", 0),
                log_dict.get("person_type"),
                log_dict.get("person_id"),
                log_dict.get("card_uid"),
                log_dict.get("tapped_at"),
                log_dict.get("status", "on_time"),
                log_dict.get("note", "")
            ))
            conn.commit()
            return cursor.rowcount > 0

    def get_pending_logs(self, limit=50):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM attendance_logs 
                WHERE synced = 0 
                ORDER BY id ASC 
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def mark_logs_synced(self, log_uuids):
        if not log_uuids:
            return
        with self.get_connection() as conn:
            cursor = conn.cursor()
            placeholders = ",".join("?" for _ in log_uuids)
            cursor.execute(f"UPDATE attendance_logs SET synced = 1 WHERE log_uuid IN ({placeholders})", log_uuids)
            conn.commit()

    def cleanup_synced_logs(self, keep_days=1):
        """
        Purges attendance logs that have already been confirmed synced (synced = 1)
        and are older than keep_days.
        keep_days=1 preserves today's logs for duplicate tap prevention and stats,
        while safely purging past days' logs to keep the local database ultra-lightweight (< 3MB).
        Unsynced records (synced = 0) are strictly preserved regardless of date.
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            offset_param = f"-{int(keep_days)} days"
            cursor.execute("""
                DELETE FROM attendance_logs 
                WHERE synced = 1 
                AND date(tapped_at) <= date('now', 'localtime', ?)
            """, (offset_param,))
            deleted = cursor.rowcount
            conn.commit()
            if deleted > 0:
                logger.info(f"Database Auto-Purge: Cleaned up {deleted} old synced attendance records.")
                try:
                    conn.execute("VACUUM")
                except Exception as e:
                    logger.debug(f"VACUUM note: {e}")
            return deleted

    def get_stats_summary(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM master_students")
            total_students = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM master_teachers")
            total_teachers = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM attendance_logs WHERE date(tapped_at) = date('now', 'localtime')")
            today_taps = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM attendance_logs WHERE synced = 0")
            unsynced_count = cursor.fetchone()[0]

            return {
                "total_students": total_students,
                "total_teachers": total_teachers,
                "today_taps": today_taps,
                "unsynced_count": unsynced_count
            }
