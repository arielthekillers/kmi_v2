import os
import sys
import time
import threading
import logging
import ctypes
from pynput import keyboard

logger = logging.getLogger("RFIDListener")

class RFIDListener:
    def __init__(self, callback, enable_lockdown=False):
        self.callback = callback
        self.enable_lockdown = enable_lockdown
        self.buffer = []
        self.last_char_time: float = 0.0
        self.listener = None
        self.is_running = False
        self._user32 = None

        if os.name == 'nt':
            try:
                self._user32 = ctypes.windll.user32
            except Exception as e:
                logger.warning(f"Failed to load user32.dll for lockdown: {e}")

    def set_lockdown(self, enabled: bool):
        self.enable_lockdown = enabled
        logger.info(f"Keyboard hook lockdown state changed to: {self.enable_lockdown}")

    def _win32_event_filter(self, msg, data):
        """
        Low-level keyboard filter (WH_KEYBOARD_LL) on Windows.
        Returns False / calls suppress_event() to block prohibited kiosk escape keys.
        """
        if not self.enable_lockdown:
            return True

        try:
            vk = data.vkCode
            flags = data.flags
            alt_down = bool(flags & 0x20)

            # 1. Windows keys & Context Menu Key
            # 0x5B = VK_LWIN, 0x5C = VK_RWIN, 0x5D = VK_APPS
            if vk in (0x5B, 0x5C, 0x5D):
                if self.listener:
                    self.listener.suppress_event()
                return False

            # 2. Alt combinations: Alt+Tab (0x09), Alt+F4 (0x73), Alt+Esc (0x1B), Alt+Space (0x20)
            if alt_down and vk in (0x09, 0x73, 0x1B, 0x20):
                if self.listener:
                    self.listener.suppress_event()
                return False

            # 3. Ctrl combinations: Ctrl+Esc (0x1B)
            if self._user32:
                ctrl_down = bool(self._user32.GetAsyncKeyState(0x11) & 0x8000)
                if ctrl_down and vk == 0x1B:
                    if self.listener:
                        self.listener.suppress_event()
                    return False

            # 4. Prohibited Function keys: F11 (0x7A), F12 (0x7B), F5 (0x74)
            if vk in (0x7A, 0x7B, 0x74):
                if self.listener:
                    self.listener.suppress_event()
                return False

        except Exception as e:
            # If suppression exception was raised, let it propagate to SystemHook
            if "SuppressException" in type(e).__name__:
                raise
            logger.debug(f"Filter error: {e}")

        return True

    def on_press(self, key):
        current_time = time.time()

        # If time between keystrokes is too long (> 400ms), reset buffer
        # This prevents manual casual typing from accidentally becoming an RFID read
        if self.buffer and (current_time - self.last_char_time > 0.4):
            self.buffer = []

        self.last_char_time = current_time

        try:
            if key == keyboard.Key.enter:
                if self.buffer:
                    card_uid = "".join(self.buffer).strip()
                    self.buffer = []
                    if len(card_uid) >= 4:
                        logger.info(f"RFID Card Detected via Global Hook: {card_uid}")
                        if self.callback:
                            threading.Thread(target=self.callback, args=(card_uid,), daemon=True).start()
            elif hasattr(key, 'char') and key.char:
                self.buffer.append(key.char)
            elif hasattr(key, 'vk') and key.vk is not None:
                if 96 <= key.vk <= 105:
                    self.buffer.append(str(key.vk - 96))
        except Exception as e:
            logger.error(f"Error handling key press: {e}")

    def start(self):
        if not self.is_running:
            self.is_running = True
            kwargs = {"on_press": self.on_press}
            if os.name == 'nt':
                kwargs["win32_event_filter"] = self._win32_event_filter

            self.listener = keyboard.Listener(**kwargs)
            self.listener.daemon = True
            self.listener.start()
            logger.info(f"RFID Global Keyboard Hook started (lockdown initial={self.enable_lockdown}).")

    def stop(self):
        if self.is_running and self.listener:
            self.listener.stop()
            self.is_running = False
            logger.info("RFID Global Keyboard Hook stopped.")
