import time
import datetime
import requests
import logging

logger = logging.getLogger("SyncService")

class SyncService:
    def __init__(self, db, server_url, device_token, interval=15, retention_days=1, on_unauthorized_cb=None):
        self.db = db
        self.server_url = server_url.rstrip("/")
        self.device_token = device_token
        self.interval = interval
        self.retention_days = retention_days
        self.on_unauthorized_cb = on_unauthorized_cb
        self.is_running = False
        self.is_online = False
        self.last_sync_time = None
        self.clock_drift_warning = False

    def _handle_unauthorized(self):
        logger.warning("Server merespon HTTP 401 Unauthorized: Perangkat telah dihapus atau token direset di server.")
        self.device_token = ""
        self.is_online = False
        if self.on_unauthorized_cb:
            try:
                self.on_unauthorized_cb()
            except Exception as e:
                logger.error(f"Error executing on_unauthorized callback: {e}")

    def get_headers(self):
        return {
            "Authorization": f"Bearer {self.device_token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

    def perform_handshake(self, server_url, setup_code, hostname=""):
        """
        Step 2 Kiosk: Mengirim setup_code ke server untuk inisiasi awal
        """
        clean_url = str(server_url).strip().rstrip("/")
        clean_code = str(setup_code).replace("-", "").replace(" ", "").strip().upper()

        if not clean_url:
            return {"success": False, "message": "URL Server tidak boleh kosong"}
        if len(clean_code) != 8:
            return {"success": False, "message": "Format Kode Setup harus 8 karakter (contoh: ABCD-EFGH)"}

        url = f"{clean_url}/api/smart-tap/handshake"
        try:
            resp = requests.post(
                url,
                json={"setup_code": clean_code, "hostname": hostname},
                headers={"Content-Type": "application/json", "Accept": "application/json"},
                timeout=12
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    self.server_url = clean_url
                    return {
                        "success": True,
                        "device": data.get("device"),
                        "server_time": data.get("server_time"),
                        "message": data.get("message", "Handshake berhasil!")
                    }
                return {"success": False, "message": data.get("message", "Kode setup salah atau kedaluwarsa")}
            return {"success": False, "message": f"Respon server HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "message": f"Gagal menghubungi server ({clean_url}): {e}"}

    def pair_with_code(self, setup_code, pairing_code):
        """
        Step 3 Kiosk: Memverifikasi kode 2FA (6 digit) bersama Kode Setup untuk menerbitkan token
        """
        clean_setup = str(setup_code).replace("-", "").replace(" ", "").strip().upper()
        clean_code = str(pairing_code).replace(" ", "").strip()
        url = f"{self.server_url}/api/smart-tap/pair"
        try:
            resp = requests.post(
                url,
                json={"setup_code": clean_setup, "pairing_code": clean_code},
                headers={"Content-Type": "application/json", "Accept": "application/json"},
                timeout=12
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    self.device_token = data.get("device_token")
                    self.is_online = True
                    return {
                        "success": True,
                        "token": self.device_token,
                        "device": data.get("device"),
                        "message": data.get("message", "Aktivasi berhasil!")
                    }
                return {
                    "success": False, 
                    "message": data.get("message", "Kode pairing salah atau kedaluwarsa"),
                    "attempts_left": data.get("attempts_left")
                }
            return {"success": False, "message": f"Respon server tidak valid (HTTP {resp.status_code})"}
        except Exception as e:
            return {"success": False, "message": f"Gagal menghubungi server: {e}"}

    def sync_master(self):
        """
        Pulls master cards, students, teachers, today's events and permissions from server
        """
        if not self.device_token:
            logger.warning("Device token is empty, skipping master sync.")
            return False

        url = f"{self.server_url}/api/smart-tap/sync-master"
        try:
            resp = requests.get(url, headers=self.get_headers(), timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    self.db.update_master_data(data)
                    self.is_online = True
                    self.last_sync_time = time.strftime("%H:%M:%S")

                    # Check clock drift between Terminal Device and Server
                    server_time_str = data.get("server_time")
                    if server_time_str:
                        try:
                            server_dt = datetime.datetime.strptime(server_time_str, "%Y-%m-%d %H:%M:%S")
                            local_dt = datetime.datetime.now()
                            diff = abs((server_dt - local_dt).total_seconds())
                            self.clock_drift_warning = (diff > 180)
                            if self.clock_drift_warning:
                                logger.warning(f"Clock drift detected: local time differs by {int(diff)}s from server ({server_time_str})")
                        except Exception:
                            pass

                    logger.info("Master data successfully synced from server.")
                    # Purge old synced logs on master sync
                    self.db.cleanup_synced_logs(keep_days=self.retention_days)
                    return True
            elif resp.status_code == 401:
                self._handle_unauthorized()
                return False
            else:
                logger.warning(f"Failed to sync master data. Status code: {resp.status_code}")
                self.is_online = False
        except Exception as e:
            logger.warning(f"Error connecting to server for sync_master: {e}")
            self.is_online = False

        return False

    def sync_logs(self):
        """
        Pushes unsynced attendance logs to server
        """
        if not self.device_token:
            return False

        pending_logs = self.db.get_pending_logs(limit=50)
        if not pending_logs:
            return True

        url = f"{self.server_url}/api/smart-tap/sync-logs"
        payload = {"logs": pending_logs}

        try:
            resp = requests.post(url, headers=self.get_headers(), json=payload, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    synced_uuids = [log["log_uuid"] for log in pending_logs]
                    self.db.mark_logs_synced(synced_uuids)
                    self.is_online = True
                    logger.info(f"Successfully pushed {len(synced_uuids)} logs to server.")

                    # Auto-purge synced logs older than retention period (default keep today only)
                    self.db.cleanup_synced_logs(keep_days=self.retention_days)
                    return True
            elif resp.status_code == 401:
                self._handle_unauthorized()
                return False
            else:
                logger.warning(f"Failed to sync logs. HTTP {resp.status_code}")
                self.is_online = False
        except Exception as e:
            logger.warning(f"Error syncing logs to server: {e}")
            self.is_online = False

        return False

    def ping(self):
        """
        Pings server to update device activity
        """
        if not self.device_token:
            return False

        url = f"{self.server_url}/api/smart-tap/ping"
        try:
            resp = requests.get(url, headers=self.get_headers(), timeout=5)
            if resp.status_code == 200:
                self.is_online = True
                return True
        except Exception:
            self.is_online = False
        return False

