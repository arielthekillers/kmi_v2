# -*- coding: utf-8 -*-
"""
Smart Tap RawInput Multi-Reader Scanner Listener
Mendengarkan input USB RFID Keyboard secara langsung dari Windows Raw Input API (WM_INPUT).
Membedakan handle USB perangkat fisik (hDevice) sehingga ketikan dari beberapa scanner
yang bersamaan TIDAK AKAN BERCAMPUR.
"""

import sys
import time
import logging
import threading
from typing import Callable, Optional, Dict

logger = logging.getLogger("RawInputScanner")

# VKey Mappings (Digits 0-9 & Numpad 0-9 & Letters A-Z)
VK_MAP = {
    0x30: '0', 0x31: '1', 0x32: '2', 0x33: '3', 0x34: '4',
    0x35: '5', 0x36: '6', 0x37: '7', 0x38: '8', 0x39: '9',
    0x60: '0', 0x61: '1', 0x62: '2', 0x63: '3', 0x64: '4',
    0x65: '5', 0x66: '6', 0x67: '7', 0x68: '8', 0x69: '9',
}
for code in range(0x41, 0x5B):
    VK_MAP[code] = chr(code)


class RawInputScannerListener:
    def __init__(self, on_scan_callback: Callable[[str, int], None]):
        """
        :param on_scan_callback: function(uid_string, device_handle)
        """
        self.on_scan_callback = on_scan_callback
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self.hwnd = None
        self._wnd_proc_ref = None

        # Isolasi buffer per USB Device fisik
        self.device_buffers: Dict[int, str] = {}
        self.last_char_times: Dict[int, float] = {}

    def start(self):
        if sys.platform != "win32":
            logger.info("RawInput listener hanya tersedia pada platform Windows.")
            return

        self.running = True
        self.thread = threading.Thread(target=self._run_loop, name="RawInputScannerThread", daemon=True)
        self.thread.start()
        logger.info("RawInputScannerListener background thread started.")

    def stop(self):
        self.running = False
        if self.hwnd and sys.platform == "win32":
            import ctypes
            user32 = ctypes.windll.user32
            user32.PostMessageW(self.hwnd, 0x0010, 0, 0) # WM_CLOSE

    def _run_loop(self):
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            WM_INPUT = 0x00FF
            WM_DESTROY = 0x0002
            RIM_TYPEKEYBOARD = 1
            RIDEV_INPUTSINK = 0x00000100
            RID_INPUT = 0x10000003

            WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_long, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)

            class WNDCLASSEXW(ctypes.Structure):
                _fields_ = [
                    ("cbSize", wintypes.UINT),
                    ("style", wintypes.UINT),
                    ("lpfnWndProc", WNDPROC),
                    ("cbClsExtra", ctypes.c_int),
                    ("cbWndExtra", ctypes.c_int),
                    ("hInstance", wintypes.HINSTANCE),
                    ("hIcon", wintypes.HICON),
                    ("hCursor", wintypes.HICON),
                    ("hbrBackground", wintypes.HBRUSH),
                    ("lpszMenuName", wintypes.LPCWSTR),
                    ("lpszClassName", wintypes.LPCWSTR),
                    ("hIconSm", wintypes.HICON),
                ]

            class RAWINPUTHEADER(ctypes.Structure):
                _fields_ = [
                    ("dwType", wintypes.DWORD),
                    ("dwSize", wintypes.DWORD),
                    ("hDevice", wintypes.HANDLE),
                    ("wParam", wintypes.WPARAM),
                ]

            class RAWKEYBOARD(ctypes.Structure):
                _fields_ = [
                    ("MakeCode", wintypes.USHORT),
                    ("Flags", wintypes.USHORT),
                    ("Reserved", wintypes.USHORT),
                    ("VKey", wintypes.USHORT),
                    ("Message", wintypes.UINT),
                    ("ExtraInformation", wintypes.ULONG),
                ]

            class RAWINPUT_UNION(ctypes.Union):
                _fields_ = [
                    ("keyboard", RAWKEYBOARD),
                ]

            class RAWINPUT(ctypes.Structure):
                _fields_ = [
                    ("header", RAWINPUTHEADER),
                    ("data", RAWINPUT_UNION),
                ]

            class RAWINPUTDEVICE(ctypes.Structure):
                _fields_ = [
                    ("usUsagePage", wintypes.USHORT),
                    ("usUsage", wintypes.USHORT),
                    ("dwFlags", wintypes.DWORD),
                    ("hwndTarget", wintypes.HWND),
                ]

            user32.CreateWindowExW.argtypes = [
                wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
                ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID
            ]
            user32.CreateWindowExW.restype = wintypes.HWND

            user32.RegisterRawInputDevices.argtypes = [
                ctypes.POINTER(RAWINPUTDEVICE),
                wintypes.UINT,
                wintypes.UINT
            ]
            user32.RegisterRawInputDevices.restype = wintypes.BOOL

            user32.GetRawInputData.argtypes = [
                wintypes.HANDLE,
                wintypes.UINT,
                wintypes.LPVOID,
                ctypes.POINTER(wintypes.UINT),
                wintypes.UINT
            ]
            user32.GetRawInputData.restype = wintypes.UINT

            user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
            user32.DefWindowProcW.restype = ctypes.c_long

            def wnd_proc(hWnd, message, wParam, lParam):
                if message == WM_INPUT:
                    size = wintypes.UINT()
                    header_size = ctypes.sizeof(RAWINPUTHEADER)
                    user32.GetRawInputData(lParam, RID_INPUT, None, ctypes.byref(size), header_size)
                    if size.value > 0:
                        raw = RAWINPUT()
                        if user32.GetRawInputData(lParam, RID_INPUT, ctypes.byref(raw), ctypes.byref(size), header_size) == size.value:
                            if raw.header.dwType == RIM_TYPEKEYBOARD:
                                # Process only KeyDown events (WM_KEYDOWN = 0x0100)
                                if raw.data.keyboard.Message == 0x0100:
                                    hDev = int(raw.header.hDevice or 0)
                                    vkey = raw.data.keyboard.VKey
                                    self._handle_keystroke(hDev, vkey)
                    return 0
                elif message == WM_DESTROY:
                    user32.PostQuitMessage(0)
                    return 0
                return user32.DefWindowProcW(hWnd, message, wParam, lParam)

            self._wnd_proc_ref = WNDPROC(wnd_proc)

            hInst = kernel32.GetModuleHandleW(None)
            className = f"SmartTapRawInputClass_{int(time.time())}"

            wc = WNDCLASSEXW()
            wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
            wc.lpfnWndProc = self._wnd_proc_ref
            wc.hInstance = hInst
            wc.lpszClassName = className
            user32.RegisterClassExW(ctypes.byref(wc))

            HWND_MESSAGE = -3
            self.hwnd = user32.CreateWindowExW(
                0, className, "SmartTapRawInputMsgWin",
                0, 0, 0, 0, 0,
                HWND_MESSAGE, None, hInst, None
            )

            rid = RAWINPUTDEVICE()
            rid.usUsagePage = 0x01 # Generic desktop
            rid.usUsage = 0x06     # Keyboard
            rid.dwFlags = RIDEV_INPUTSINK
            rid.hwndTarget = self.hwnd

            reg_success = user32.RegisterRawInputDevices(ctypes.byref(rid), 1, ctypes.sizeof(RAWINPUTDEVICE))
            if not reg_success:
                logger.error("Gagal mendaftarkan RegisterRawInputDevices.")
            else:
                logger.info("RegisterRawInputDevices berhasil aktif untuk semua USB scanner.")

            msg = wintypes.MSG()
            while self.running and user32.GetMessageW(ctypes.byref(msg), 0, 0, 0) > 0:
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))

            user32.UnregisterClassW(className, hInst)
            logger.info("RawInputScannerListener window loop selesai.")

        except Exception as e:
            logger.error(f"Error in RawInputScannerListener: {e}", exc_info=True)

    def _handle_keystroke(self, hDev: int, vkey: int):
        now = time.time()
        
        # Reset buffer jika jeda antar tombol > 0.8 detik (menandakan bukan scanner cepat)
        last_time = self.last_char_times.get(hDev, 0)
        if (now - last_time) > 0.8 and hDev in self.device_buffers:
            self.device_buffers[hDev] = ""

        self.last_char_times[hDev] = now

        # VK_RETURN (0x0D = Enter) -> akhir dari UID RFID
        if vkey == 0x0D:
            buffered_uid = self.device_buffers.get(hDev, "").strip()
            self.device_buffers[hDev] = ""
            
            # RFID UID biasanya minimal 4 digit karakter alfanumerik
            if len(buffered_uid) >= 4:
                logger.info(f"RawInput detected UID '{buffered_uid}' from device handle {hDev}")
                if self.on_scan_callback:
                    try:
                        self.on_scan_callback(buffered_uid, hDev)
                    except Exception as ex:
                        logger.error(f"Callback error on card scanned: {ex}")
        else:
            char = VK_MAP.get(vkey)
            if char:
                curr = self.device_buffers.get(hDev, "")
                # Batasi panjang buffer maksimal 32 karakter agar aman
                if len(curr) < 32:
                    self.device_buffers[hDev] = curr + char

