@echo off
title Memulai Smart Tap Kiosk...
cd /d "%~dp0"

:: Otomatis unblock file yang diblokir keamanan Windows karena hasil download internet
powershell -WindowStyle Hidden -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse | Unblock-File" >nul 2>&1

:: Jalankan Smart Tap Kiosk
start "" "%~dp0SmartTapKiosk.exe"
exit
